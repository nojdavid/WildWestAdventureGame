package com.noahdavidson.luckofthewest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by noahdavidson on 7/6/16.
 */
public class GameBoardActivity extends AppCompatActivity {

    int score = 100;
    int day = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameboard);

        TextView txScore = (TextView)findViewById(R.id.Score);
        txScore.setText("$ " + String.valueOf(score));

        TextView txDay = (TextView)findViewById(R.id.Day);
        txScore.setText("Day " + String.valueOf(txDay));
    }
}
